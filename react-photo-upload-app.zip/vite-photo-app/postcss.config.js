/**
 * PostCSS Configuration
 * - Mengaktifkan Tailwind CSS dan Autoprefixer
 */
export default {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
}
